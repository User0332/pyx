import js2py
import inspect
from . import tags
from typing import Callable
from flask import Flask